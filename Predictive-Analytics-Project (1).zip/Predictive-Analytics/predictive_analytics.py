# Predictive Analytics Using Historical Data
# Model: Linear Regression
# Dataset: Synthetic monthly sales data for learning/demo purposes

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# 1. Load and clean historical data
df = pd.read_csv("historical_data.csv")
df["Month"] = pd.to_datetime(df["Month"], errors="coerce")
df["Sales"] = pd.to_numeric(df["Sales"], errors="coerce")
df = df.dropna(subset=["Month", "Sales"]).sort_values("Month")
df = df.drop_duplicates(subset=["Month"])

if len(df) < 12:
    raise ValueError("Please provide at least 12 valid monthly records.")

# Convert dates to a sequential time index for regression
df = df.reset_index(drop=True)
df["Month_Number"] = np.arange(len(df))

X = df[["Month_Number"]]
y = df["Sales"]

# 2. Chronological train-test split (last 20% for testing)
split_index = int(len(df) * 0.8)
X_train, X_test = X.iloc[:split_index], X.iloc[split_index:]
y_train, y_test = y.iloc[:split_index], y.iloc[split_index:]

# 3. Train model and evaluate it on unseen historical months
model = LinearRegression()
model.fit(X_train, y_train)
test_predictions = model.predict(X_test)

mae = mean_absolute_error(y_test, test_predictions)
rmse = np.sqrt(mean_squared_error(y_test, test_predictions))
r2 = r2_score(y_test, test_predictions)

print("=== MODEL EVALUATION ===")
print(f"Mean Absolute Error (MAE): {mae:.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")
print(f"R-squared (R2): {r2:.3f}")

# 4. Refit on all historical data and forecast the next 6 months
final_model = LinearRegression()
final_model.fit(X, y)

future_steps = 6
future_month_numbers = np.arange(len(df), len(df) + future_steps)
future_predictions = final_model.predict(
    pd.DataFrame({"Month_Number": future_month_numbers})
)
future_dates = pd.date_range(
    df["Month"].max() + pd.offsets.MonthBegin(1),
    periods=future_steps,
    freq="MS"
)

forecast_df = pd.DataFrame({
    "Month": future_dates.strftime("%Y-%m"),
    "Predicted_Sales": np.round(future_predictions, 2)
})

print("\n=== NEXT 6 MONTHS FORECAST ===")
print(forecast_df.to_string(index=False))
forecast_df.to_csv("future_forecast.csv", index=False)

# 5. Visualize actual data and future forecast
plt.figure(figsize=(11, 6))
plt.plot(df["Month"], df["Sales"], marker="o", label="Historical Sales")
plt.plot(future_dates, future_predictions, marker="o", linestyle="--",
         label="Forecast (Next 6 Months)")
plt.axvline(df["Month"].max(), linestyle=":", label="Forecast Starts")
plt.title("Monthly Sales: Historical Data and Forecast")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("prediction_plot.png", dpi=150)
plt.show()

print("\nFiles created: future_forecast.csv and prediction_plot.png")
print("Note: This is a practice forecast based on synthetic sample data.")
