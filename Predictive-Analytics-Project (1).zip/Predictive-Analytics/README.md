# Predictive Analytics Using Historical Data

## Objective
Build a predictive model using historical data to forecast future trends, evaluate model accuracy, and visualize the results.

## Project Overview
This project uses **Linear Regression** to learn the trend in historical monthly sales and forecast sales for the next six months.

**Dataset note:** `historical_data.csv` contains synthetic sample data created for practice. It is not real company or Thiranex data.

## Features
- Loads historical monthly sales from CSV.
- Cleans invalid dates/numbers, removes missing rows and duplicate months, and sorts the records.
- Splits data chronologically into training and testing sets.
- Trains a Linear Regression model.
- Evaluates predictions using MAE, RMSE, and R-squared (R²).
- Forecasts the next six months.
- Creates a graph and saves the forecast to CSV.

## Tools and Libraries
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn

## How to Run
1. Install Python 3.10 or newer.
2. Open this folder in VS Code.
3. Open the terminal in VS Code.
4. Install the dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Run the project:

   ```bash
   python predictive_analytics.py
   ```

## Output
The program prints MAE, RMSE, R², and the next six months' forecast. It also generates:
- `future_forecast.csv`
- `prediction_plot.png`

## Model Evaluation
- **MAE:** Average absolute difference between actual and predicted values. Lower is better.
- **RMSE:** Gives more weight to larger prediction errors. Lower is better.
- **R²:** Indicates how well the model explains variation in the test data. Values closer to 1 generally indicate a better fit; it can be negative.

## Limitation
Linear Regression assumes a roughly linear trend. Real sales can be affected by seasonality, promotions, competition, and other factors. The forecast is for demonstration and should not be treated as a real business prediction.
